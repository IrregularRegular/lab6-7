from django.test import TestCase
from django.urls import reverse
from .models import Item

class ItemModelTest(TestCase):
    def setUp(self):
        self.item = Item.objects.create(name="Тестовый предмет", description="Описание")

    def test_item_creation(self):
        self.assertEqual(self.item.name, "Тестовый предмет")
        self.assertEqual(self.item.description, "Описание")

class ItemCRUDViewTest(TestCase):
    def setUp(self):
        self.item = Item.objects.create(name="Тестовый предмет", description="Описание")
        self.list_url = reverse('item_list')
        self.detail_url = reverse('item_detail', args=[self.item.id])
        self.create_url = reverse('item_create')
        self.update_url = reverse('item_update', args=[self.item.id])
        self.delete_url = reverse('item_delete', args=[self.item.id])

    def test_list_view(self):
        response = self.client.get(self.list_url)
        self.assertEqual(response.status_code, 200)

    def test_detail_view(self):
        response = self.client.get(self.detail_url)
        self.assertEqual(response.status_code, 200)

    def test_create_view(self):
        data = {'name': 'Новый предмет', 'description': 'Новое описание'}
        response = self.client.post(self.create_url, data)
        self.assertEqual(response.status_code, 302)

    def test_update_view(self):
        data = {'name': 'Обновленный', 'description': 'Обновленное'}
        response = self.client.post(self.update_url, data)
        self.assertEqual(response.status_code, 302)

    def test_delete_view(self):
        response = self.client.post(self.delete_url)
        self.assertEqual(response.status_code, 302)
