import os
from django.http import HttpResponse
from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from docx import Document
from .models import Item
from django.conf import settings

class ItemListView(ListView):
    model = Item
    template_name = 'items/item_list.html'

class ItemDetailView(DetailView):
    model = Item
    template_name = 'items/item_detail.html'

class ItemCreateView(CreateView):
    model = Item
    fields = ['name', 'description']
    template_name = 'items/item_form.html'

class ItemUpdateView(UpdateView):
    model = Item
    fields = ['name', 'description']
    template_name = 'items/item_form.html'

class ItemDeleteView(DeleteView):
    model = Item
    template_name = 'items/item_confirm_delete.html'
    success_url = reverse_lazy('item_list')

def export_tests_to_word(request):
    document = Document()
    document.add_heading('Тесты CRUD приложения (Задание 7)', 0)
    
    # Более надежный путь к файлу tests.py
    current_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_dir, 'tests.py')
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            test_code = f.read()
        document.add_paragraph(test_code)
    except Exception as e:
        document.add_paragraph(f"Ошибка при чтении файла: {str(e)}")
        
    response = HttpResponse(
        content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    )
    response['Content-Disposition'] = 'attachment; filename=django_tests.docx'
    document.save(response)
    return response
